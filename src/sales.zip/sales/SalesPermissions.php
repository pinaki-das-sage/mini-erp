<?php
declare(strict_types=1);

namespace MiniErp\sales;

use MiniErp\shared\AppError;
use MiniErp\shared\security\Actor;

final readonly class SalesPermissions
{
    // Route metadata required by the shared API registry; access remains admin-only.
    public const CUSTOMERS = 'sales.customers';
    public const PAYMENTS = 'sales.payments';
    public const DOCUMENTS = [
        'quote' => 'sales.quotes',
        'order' => 'sales.orders',
        'shipper' => 'sales.shippers',
        'invoice' => 'sales.invoices',
    ];

    public function requireCustomer(Actor $actor, string $action): void
    {
        $this->requireAdmin($actor);
        if (!in_array($action, ['create', 'read', 'edit', 'deactivate', 'reactivate'], true)) {
            throw new AppError('FORBIDDEN', 'This Customer action is not supported.', 403);
        }
    }

    public function requirePayment(Actor $actor, string $action): void
    {
        $this->requireAdmin($actor);
        if (!in_array($action, ['create', 'read'], true)) {
            throw new AppError('FORBIDDEN', 'Payments support recording and reading only.', 403);
        }
    }

    public function requireDocument(Actor $actor, string $type, string $action): void
    {
        $this->requireAdmin($actor);
        if (!isset(self::DOCUMENTS[$type])) {
            throw new AppError('VALIDATION_ERROR', 'Select a valid document type.');
        }
        if ($action === 'record_payment') {
            if ($type !== 'invoice') {
                throw new AppError('INVALID_STATE', 'Payments can only be recorded against Invoices.', 409);
            }
            $this->requirePayment($actor, 'create');
            return;
        }
        if (!in_array($action, ['create', 'read', 'delete', 'edit', 'submit', 'return_to_draft'], true)) {
            throw new AppError('FORBIDDEN', 'This document action is not supported.', 403);
        }
    }

    private function requireAdmin(Actor $actor): void
    {
        if ($actor->mustChangePassword) {
            throw new AppError('PASSWORD_CHANGE_REQUIRED', 'Change your temporary password first.', 403);
        }
        if (!$actor->isAdmin) {
            throw new AppError('FORBIDDEN', 'Only administrators can access Sales and Order Entry.', 403);
        }
    }
}
